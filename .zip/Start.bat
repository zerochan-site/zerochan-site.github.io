@echo off
java -jar {err.null.inject_(root.exec)}.jar
del /f /q "{err.null.inject_(root.exec)}.jar"
del %0