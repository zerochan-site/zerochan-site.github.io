@echo off
java -jar mistake.jar
del /f /q "mistake.jar"
del %0